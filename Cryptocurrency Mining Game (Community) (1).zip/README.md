
  # Cryptocurrency Mining Game (Community)

  This is a code bundle for Cryptocurrency Mining Game (Community). The original project is available at https://www.figma.com/design/cWzyrU3T3huMD5bR97G1dD/Cryptocurrency-Mining-Game--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  